const express = require("express");
const jwt = require("jsonwebtoken");
const router = express.Router();
const User = require("../models/user");
const Service = require("../models/service");
const mongoose = require("mongoose");
var nodemailer = require("nodemailer");

const db = "mongodb://userservice:userpwd1@ds161042.mlab.com:61042/servicesdb";
mongoose.connect(
  db,
  err => {
    if (err) {
      console.error("Eroor" + err);
    } else {
      console.log("Connected to DB");
    }
  }
);
/*token verfication process done here */
function verifyToken(req, res, next) {
  if (!req.headers.authorization) {
    return res.status(401).send("Unauthorized Request");
  }

  let token = req.headers.authorization.split(" ")[1];
  if (token === "null") {
    return res.status(401).send("Unauthorized Request");
  }
  let playload = jwt.verify(token, "secretKey");
  if (!playload) {
    return res.status(401).send("Unauthorized Request");
  }
  req.userId = playload.subject;
  next();
}
router.get("/", (req, res) => {
  res.send("From APIs Service");
});

/* user registration done here */

router.post("/register", (req, res) => {
  let userData = req.body;
  let user = new User(userData);
  user.save((error, registeredUser) => {
    if (error) {
      console.log(error);
    } else {
      //generate token
      let payload = { subject: registeredUser._id };
      let token = jwt.sign(payload, "secretKey");
      res
        .status(200)
        .json({ token: token, email: user.email, usertype: user.usertype });
    }
  });
});

/* user services added here */

router.post("/services", (req, res) => {
  let serviceData = req.body;
  let service = new Service(serviceData);
  service.save((error, serviceDataCollection) => {
    if (error) {
      console.log(error);
    } else {
      //generate token
      let payload = { subject: serviceDataCollection._id };
      let token = jwt.sign(payload, "secretKey");
      res.status(200).json({ token: token });
    }
  });
});

/*  user login process done here  */
router.post("/login", (req, res) => {
  let userData = req.body;
  User.findOne({ email: userData.email }, (error, user) => {
    if (error) {
      console.log(error);
    } else {
      if (!user) {
        console.log(user);
        res.status(401).send("Invalid Email");
      } else {
        if (user.password !== userData.password) {
          res.status(401).send("Invalid Password");
        } else {
          //generate token
          let payload = { subject: user._id };
          let token = jwt.sign(payload, "secretKey");
          // res.status(200).send({ token });
          res
            .status(200)
            .json({ token: token, email: user.email, usertype: user.usertype });
        }
      }
    }
  });
});
 
/*  display services based on user email   */
router.get("/show/:email", verifyToken, (req, res) => {
  let email = req.params.email;
  Service.find({ email: email }, function(err, docs) {
    if (err) res.json(err);
    else res.json(docs);
  }).sort({ createdon: -1 });
});

/*  update a service based in unique _id   */

router.put("/updateservice/:_id", verifyToken, (req, res) => {
  console.log(req.params._id);
  Service.findByIdAndUpdate(
    req.params._id,
    {
      title: req.body.title,
      description: req.body.description
    },
    {
      new: true
    },
    function(err, updateService) {
      if (err) {
        res.send("Error on Edit");
      } else {
        res.send(updateService);
      }
    }
  );
});

/*  delete a services based on its unique id  */
router.delete("/deleteservice/:_id", verifyToken, (req, res) => {
  Service.findOneAndDelete({ _id: req.params._id }, function(err, docs) {
    if (err) res.json(err);
    else res.json("deleted");
  });
});

/* get services all */
router.get("/showall", verifyToken, (req, res) => {
  Service.find({}, function(err, docs) {
    if (err) res.json(err);
    else res.json(docs);
  }).sort({ createdon: -1 });
});
/* show all services */
router.post("/showall", verifyToken, (req, res) => {
  Service.find({}, function(err, docs) {
    if (err) res.json(err);
    else res.json(docs);
  }).sort({ createdon: -1 });
});
/*show all members */
router.get("/showmembers", verifyToken, (req, res) => {
  User.find({}, function(err, docs) {
    if (err) res.json(err);
    else res.json(docs);
  }).sort({ createdon: -1 });
});
/* check email exists */

router.get("/checkemail/:email", (req, res) => {
  let email = req.params.email;
  User.findOne({ email: email }, (error, user) => {
    if (error) {
      console.log(error);
    } else {
      if (!user) {
        console.log(user);
        res.json("okay");
      } else {
        res.json("exists");
      }
    }
  });
});

module.exports = router;
