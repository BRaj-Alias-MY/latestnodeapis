const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const serviceSchema = new Schema({
  title: String,
  description: String,
  email: String,
  createdon: { type: Date, default: Date.now }
});
module.exports = mongoose.model("service", serviceSchema, "services");
